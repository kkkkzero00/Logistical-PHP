﻿function test_script(){
	document.write('<font color="red">这是用script加入的动态内容</font>');
}